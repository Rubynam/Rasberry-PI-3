import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
import numpy as np
import os
import encode_decode
#
#X, Y, test_x, test_y = encode_decode.decode_data_set('training_img_re_2.nba', 'training_label_re_2.nba',
                                                     #'testing_img_re.nba', 'testing_label_re.nba')
#X = X.reshape([-1, 36, 48, 1])
#test_x = test_x.reshape([-1, 36, 48, 1])

convnet = input_data(shape=[None, 36, 48, 1], name='input')

convnet = conv_2d(convnet, 16, 5, activation='relu')
convnet = max_pool_2d(convnet, 2)

convnet = conv_2d(convnet, 32, 5, activation='relu')
convnet = max_pool_2d(convnet, 2)

# convnet = conv_2d(convnet, 64, 5, activation='relu')
# convnet = max_pool_2d(convnet, 2)
#
# convnet = conv_2d(convnet, 72, 5, activation='relu')
# convnet = max_pool_2d(convnet, 2)

convnet = fully_connected(convnet, 32, activation='relu')
convnet = dropout(convnet, 0.75)

# convnet = fully_connected(convnet, 256, activation='relu')
# convnet = dropout(convnet, 0.75)

# convnet = fully_connected(convnet, 256, activation='relu')
# convnet = dropout(convnet, 0.75)
#
# convnet = fully_connected(convnet, 128, activation='relu')
# convnet = dropout(convnet, 0.75)

convnet = fully_connected(convnet, 3, activation='softmax')
convnet = regression(convnet, optimizer='adam', learning_rate=0.001, loss='categorical_crossentropy', name='targets')

model = tflearn.DNN(convnet, tensorboard_verbose=3, tensorboard_dir='logsModel8')
model.load('model8/autodrive_v8.model')

#model.fit({'input': X}, {'targets': Y}, n_epoch=3, validation_set=({'input': test_x}, {'targets': test_y}),
#          snapshot_step=500, show_metric=True)

#model.save('model8/autodrive_v8.model')



from scipy import misc
image = misc.imread('frame00404-1.jpg')
import datetime
result = np.round(model.predict([image.reshape(36, 48, 1)])[0]).dot(np.arange(3).reshape(3, 1))
print(result + 1)
print('Start !!!!!!!!!!!!!!!!!!!!!!!!!')
#
a = datetime.datetime.now()
#
for it in range(500):
     result = np.round(model.predict([image.reshape(36, 48, 1)])[0]).dot(np.arange(3).reshape(3, 1))
     print(it, '   :', result + 1)

print(datetime.datetime.now() - a)
#print(np.round(model.predict([image.reshape(28,28,1)])[0]))
#print(result)
#print(test_x[1])