
import os
import struct as struct
import numpy as np
from PIL import Image


def dense_to_one_hot(labels_dense, num_classes=3):
    """Convert class labels from scalars to one-hot vectors."""
    num_labels = labels_dense.shape[0]
    index_offset = np.arange(num_labels) * num_classes
    labels_one_hot = np.zeros((num_labels, num_classes))
    labels_one_hot.flat[index_offset + labels_dense.ravel()] = 1
    return labels_one_hot


def int_to_bytes(number):
    b = bytearray([0, 0, 0, 0])  # init
    b[0] = number & 0xFF
    number >>= 8
    b[1] = number & 0xFF
    number >>= 8
    b[2] = number & 0xFF
    number >>= 8
    b[3] = number & 0xFF

    return b


def encode_data_set(image_path, image_output, label_output):
    width, height = 0, 0
    f_images_output = open(image_output, 'wb')
    f_labels_output = open(label_output, 'wb')

    header_f_image = bytearray()
    header_f_label = bytearray()

    data_image = bytearray()
    data_label = bytearray()

    if os.path.isdir(image_path):
        print('>>>----------------------------- Bat dau doc du lieu hinh -----------------------------<<<')
        count = len(os.listdir(image_path))
        process_count = 0
        for files in os.listdir(image_path):
            file = os.path.join(image_path, files)
            
            label = int(files.split('-')[1].split('.')[0]) - 1
            img = Image.open(file)
            width, height = img.size
            if img.mode == 'L':
                pixels = img.load()
                for x in range(0, height):
                    for y in range(0, width):
                        data_image.append(pixels[y, x])
                data_label.append(label)
                process_count += 1
                if process_count % 1000 == 0:
                    print (process_count, ' / ', count)
                
            else:
                print('>>====== !!!!! File khong hop le, BPP > 8 :  ' + files)
                
        print (process_count, ' / ', count)
        
        header_f_image += int_to_bytes(count)[:]
        header_f_label += int_to_bytes(count)[:]

        header_f_image += int_to_bytes(width)
        header_f_image += int_to_bytes(height)

        header_f_image += data_image[:]
        data_image = header_f_image
        f_images_output.write(data_image)

        header_f_label += data_label[:]
        data_label = header_f_label
        f_labels_output.write(data_label)

        print('Done !')
    else:
        print('Thu muc khong ton tai !')

    f_images_output.close()
    f_labels_output.close()


def decode_data_set(training_img_dataset, training_label_dataset, testing_img_dataset, testing_label_dataset):

    if os.path.exists(training_img_dataset) and os.path.exists(training_label_dataset) \
            and os.path.exists(testing_img_dataset) and os.path.exists(testing_label_dataset):

        f_training_image_dataset = open(training_img_dataset, 'rb')
        f_training_label_dataset = open(training_label_dataset, 'rb')
        f_testing_img_dataset = open(testing_img_dataset, 'rb')
        f_testing_label_dataset = open(testing_label_dataset, 'rb')

        # extract training data images

        print('Extracting training data images . . . . .')
        n_training_images = struct.unpack('i', f_training_image_dataset.read(4))[0]
        width = struct.unpack('i', f_training_image_dataset.read(4))[0]
        height = struct.unpack('i', f_training_image_dataset.read(4))[0]
        # print(n_training_images * width * height, "   <=====")
        buf_training_images = f_training_image_dataset.read()
        training_data_images = np.frombuffer(buf_training_images, dtype=np.uint8)
        # training_data_images = training_data_images.reshape(n_training_images, height, width, 1)
        training_data_images = training_data_images.reshape(n_training_images, height * width)
        training_data_images = np.multiply(training_data_images, 1.0 / 255.0)

        # extract training data labels

        print('Extracting training data labels . . . . .')
        n_training_labels = struct.unpack('i', f_training_label_dataset.read(4))[0]
        buf_training_labels = f_training_label_dataset.read(n_training_labels)
        training_data_labels = np.frombuffer(buf_training_labels, dtype=np.uint8)
        training_data_labels = dense_to_one_hot(training_data_labels, num_classes=3)

        # extract testing data images

        print('Extracting testing data images . . . . .')
        n_testing_images = struct.unpack('i', f_testing_img_dataset.read(4))[0]
        width = struct.unpack('i', f_testing_img_dataset.read(4))[0]
        height = struct.unpack('i', f_testing_img_dataset.read(4))[0]
        buf_testing_images = f_testing_img_dataset.read(n_testing_images * width * height)
        testing_data_images = np.frombuffer(buf_testing_images, dtype=np.uint8)
        # testing_data_images = testing_data_images.reshape(n_testing_images, height, width, 1)
        testing_data_images = testing_data_images.reshape(n_testing_images, height * width)
        testing_data_images = np.multiply(testing_data_images, 1.0 / 255.0)

        # extract testing data labels

        print('Extracting testing data labels . . . . .')
        n_testing_labels = struct.unpack('i', f_testing_label_dataset.read(4))[0]
        buf_testing_labels = f_testing_label_dataset.read(n_testing_labels)
        testing_data_labels = np.frombuffer(buf_testing_labels, dtype=np.uint8)
        testing_data_labels = dense_to_one_hot(testing_data_labels, num_classes=3)
        print('Extracting dataset success !')

        return training_data_images, training_data_labels, testing_data_images, testing_data_labels

    else:
        print('Datasets khong ton tai, kiem tra lai')

    return None, None, None, None


# encode_data_set('training_images_2','training_img_2.nba','training_label_2.nba')

# fin = open('training_img_v1.nba','rb')
# n = struct.unpack('i', fin.read(4))[0]
# width = struct.unpack('i', fin.read(4))[0]
# height = struct.unpack('i', fin.read(4))[0]
# buf = fin.read(width * height * n)
# data = np.frombuffer(buf, dtype=np.uint8)
# data = data.reshape(n, height, width, 1)
# # data = np.multiply(data, 1.0 / 255.0)
# from scipy import misc
# import glob
# for image_path in glob.glob("frame00001-2.jpg"):
#     image = misc.imread(image_path)

# print(data)
# print(image.reshape(240, 320, 1))
# print(data[0] == image.reshape(240, 320, 1))

# fin_label = open('training-label.nba', 'rb')
# n = struct.unpack('i', fin_label.read(4))[0]
# buf = fin_label.read(n)
# data_labels = np.frombuffer(buf, dtype=np.uint8)
#
# print(dense_to_one_hot(data_labels)[6554])


# str = "so71_2.png"
#
# print(str.split('_')[1].split('.')[0])


# lstFolder = os.listdir('dataset-images/testing')
# count = 0
# for folder in lstFolder:
#
#     label = folder
#     lstFile_training = os.path.join('dataset-images/testing', folder)
#
#     count += len(os.listdir(lstFile_training))
#
# print(count)


# lstFile_testing = os.path.join('dataset-image/testing', folder)

# encode_data_set('testing_v1', 'testing_img_v1.nba', 'testing_label_v1.nba')

# training_imgs, training_labels, testing_imgs, testing_labels = decode_data_set('training-imgs.nba', 'training-label.nba', 'testing-imgs.nba', 'testing-label.nba')
#
# print(len(training_imgs), "  ", len(training_labels))
#
# print(len(testing_imgs), "   ", len(testing_labels))