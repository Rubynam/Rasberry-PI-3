﻿1> Tạo thiết lập môi trường python cho thu mục example
2> Cài đặt đủ các thư viện numpy, scipy, matplotlib, pillow, tensorflow, tflearn
3> Để thực hiện chạy model ==> chạy file run.py